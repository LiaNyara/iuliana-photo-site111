📸 Iuliana Photo Site - Pronto per Vercel

1. Vai su https://vercel.com
2. Accedi con Google o GitHub
3. Clicca 'Add New Project'
4. Trascina questa cartella (scompattata)
5. Clicca 'Deploy' e il sito sarà online

✅ Struttura compatibile con Vercel (public/, JSX incluso)
